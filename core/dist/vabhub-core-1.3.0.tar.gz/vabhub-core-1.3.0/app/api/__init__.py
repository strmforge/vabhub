#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
API模块初始化
"""

# API路由模块